// ESP8266_implement.h - WIFI实现
// Copyright (c) 2016 CreatBot. All Right Reserved.
// Developer Lyn Lee, 20 July 2016.

#ifdef WIFI_SUPPORT
  #error "Sorry! You cann't use WIFI."
#endif //WIFI_SUPPORT

