/*
 * Sequence.h
 *
 *  Created on: Nov 16, 2018
 *      Author: CreatBot-SW
 */

#include "MarlinConfig.h"

#ifndef SEQUENCE_H_
#define SEQUENCE_H_

#ifdef REG_USE_HARDWARE
  #error "Sorry! You cann't use hardware registration function. Please undefined REG_USE_HARDWARE."
#endif

#endif /* SEQUENCE_H_ */
